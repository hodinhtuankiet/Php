<?php
 $a = 'h';
 switch($a)
{
case 'x':
 echo "Mùa xuân ! <br/>";break;
case 'h':
 echo "Mùa hạ !<br/>";break;
case 't':
 echo "Mùa thu !<br/>";break;
case 'd':
 echo "Mùa đông !<br/>";break;
default: echo "Không có mùa này !";
 }
