<?php
// Lấy giá trị từ form
$side1 = $_POST['side1'];
$side2 = $_POST['side2'];
$side3 = $_POST['side3'];

// Kiểm tra xem các giá trị hợp lệ
if ($side1 <= 0 || $side2 <= 0 || $side3 <= 0) {
    echo "Vui lòng nhập các giá trị dương.";
} elseif ($side1 + $side2 <= $side3 || $side1 + $side3 <= $side2 || $side2 + $side3 <= $side1) {
    echo "Ba cạnh không tạo thành một tam giác.";
} else {
    // Xác định loại tam giác
    if ($side1 == $side2 && $side2 == $side3) {
        echo "Đây là tam giác đều.";
    } elseif ($side1 == $side2 || $side2 == $side3 || $side1 == $side3) {
        echo "Đây là tam giác cân.";
    } else {
        echo "Đây là tam giác thường.";
    }

    // Tính chu vi
    $perimeter = $side1 + $side2 + $side3;
    echo "<br>Chu vi tam giác: $perimeter";

    // Tính diện tích bằng công thức Heron
    $s = $perimeter / 2;
    $area = sqrt($s * ($s - $side1) * ($s - $side2) * ($s - $side3));
    echo "<br>Diện tích tam giác: $area";
}
